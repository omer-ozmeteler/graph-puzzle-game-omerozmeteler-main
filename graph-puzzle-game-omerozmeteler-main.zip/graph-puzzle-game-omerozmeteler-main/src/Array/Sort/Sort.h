//
// Created by Olcay Taner YILDIZ on 27.05.2023.
//

#ifndef DATASTRUCTURES_CPP_SORT_H
#define DATASTRUCTURES_CPP_SORT_H


class Sort {
    virtual void sort(int* A, int size) = 0;
};


#endif //DATASTRUCTURES_CPP_SORT_H
