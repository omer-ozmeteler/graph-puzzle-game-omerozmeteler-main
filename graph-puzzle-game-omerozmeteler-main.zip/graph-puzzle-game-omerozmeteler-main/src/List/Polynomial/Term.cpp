//
// Created by Olcay Taner YILDIZ on 26.03.2023.
//

#include "Term.h"

Term::Term(int coefficient, int degree) {
    this->coefficient = coefficient;
    this->degree = degree;
}

Term::Term() {

}
