//
// Created by Olcay Taner YILDIZ on 26.03.2023.
//

#ifndef DATASTRUCTURES_CPP_TERM_H
#define DATASTRUCTURES_CPP_TERM_H


class Term {
public:
    int coefficient;
    int degree;
    Term();
    Term(int coefficient, int degree);
};


#endif //DATASTRUCTURES_CPP_TERM_H
